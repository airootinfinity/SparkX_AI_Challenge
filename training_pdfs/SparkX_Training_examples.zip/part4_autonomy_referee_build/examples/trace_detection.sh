#!/usr/bin/env bash
# Trace one detection through the starter memory node, without the simulator.
# Run from sparkx_ws after `colcon build`. Uses its own ROS domain so it cannot disturb a running sim.
#
#   bash trace_detection.sh
set -e
source install/setup.bash
export ROS_DOMAIN_ID=44

# the starter memory.py, alone. This is the file `ros2 run sparkx_team memory` would start;
# calling it directly lets the script stop it again with a plain `kill`.
"$(ros2 pkg prefix sparkx_team)/lib/sparkx_team/memory" &
MEM=$!
sleep 3

# what perception.py would publish for one survivor at (12.4, -3.1) in the map frame,
# sent twice: the same person seen in two camera frames
DET="{header: {frame_id: map}, detections: [{results: [{hypothesis: {class_id: survivor, score: 0.9},
      pose: {pose: {position: {x: 12.4, y: -3.1, z: 0.3}}}}]}]}"
for i in 1 2; do
  ros2 topic pub --once /perception/detections vision_msgs/msg/Detection3DArray "$DET" > /dev/null
done

# what memory.py publishes from it (once a second)
ros2 topic echo --once /team/semantic_map

kill $MEM
