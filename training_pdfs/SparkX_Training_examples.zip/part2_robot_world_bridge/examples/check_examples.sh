#!/usr/bin/env bash
# check_examples.sh - validate the Part 2 example files without starting a simulation.
#   cd examples && ./check_examples.sh
# Needs a sourced ROS 2 Jazzy (xacro, check_urdf, gz sdf, ros2). The two short ROS runs use
# ROS_DOMAIN_ID=42 and their own Gazebo partition, so they cannot disturb anything else.
set -euo pipefail
cd "$(dirname "$0")"
out=$(mktemp -d)
export ROS_DOMAIN_ID=42 GZ_PARTITION=sparkx_training_p2 GZ_IP=127.0.0.1

echo "== 1. mini_rover.urdf.xacro: xacro -> URDF -> check_urdf"
xacro mini_rover.urdf.xacro > "$out/mini_rover.urdf"
check_urdf "$out/mini_rover.urdf"

echo "== 2. mini_rover: URDF -> SDF (what Gazebo builds from it)"
gz sdf -p "$out/mini_rover.urdf" > "$out/mini_rover.sdf" 2> /dev/null
grep -E "<link name|<joint name|<collision name|<sensor name" "$out/mini_rover.sdf"

echo "== 3. simple_world.sdf"
gz sdf -k simple_world.sdf

echo "== 4. mini_bridge.yaml: start the bridge for 4 s (no simulator needed)"
timeout -s INT 4 ros2 run ros_gz_bridge parameter_bridge --ros-args -r __node:=mini_bridge \
    -p config_file:="$PWD/mini_bridge.yaml" 2>&1 | grep -o "Creating.*" || true

echo "== 5. robot_state_publisher with the mini rover: which static frames?"
python3 - "$out" <<'EOF'
import sys, yaml
d = sys.argv[1]
yaml.safe_dump({'robot_state_publisher': {'ros__parameters': {
    'robot_description': open(f'{d}/mini_rover.urdf').read()}}}, open(f'{d}/rsp.yaml', 'w'))
EOF
timeout -s INT 6 ros2 run robot_state_publisher robot_state_publisher --ros-args \
    --params-file "$out/rsp.yaml" > "$out/rsp.log" 2>&1 &
sleep 3
timeout 3 ros2 topic echo /tf_static --once | grep -E "frame_id" || true
wait || true
grep -E "WARN|ERROR" "$out/rsp.log" || echo "(robot_state_publisher: no warnings)"

echo "== 6. the two launch files: parse them, start nothing"
for f in view_mini_rover.launch.py mini_sim.launch.py; do
    ros2 launch "./$f" --print > /dev/null && echo "$f OK"
done
rm -rf "$out"
