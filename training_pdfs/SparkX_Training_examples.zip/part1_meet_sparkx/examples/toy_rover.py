#!/usr/bin/env python3
"""SparkX training, Part 1: a toy "rover" node that talks to toy_referee.py.

  subscribes  /toy/status  (std_msgs/String)
  subscribes  /toy/hints   (std_msgs/String, transient-local: gets the clue even if it starts late)
  publishes   /toy/cmd_vel (geometry_msgs/Twist), like the real /cmd_vel
  calls       /toy/report  (std_srvs/SetBool) twice: once while "moving", once "stopped"

Start toy_referee.py first, then (in a second terminal):
  source /opt/ros/jazzy/setup.bash
  export ROS_DOMAIN_ID=41
  python3 toy_rover.py
It stops by itself after six status messages.
"""
import rclpy
from geometry_msgs.msg import Twist
from rclpy.node import Node
from rclpy.qos import DurabilityPolicy, QoSProfile, ReliabilityPolicy
from std_msgs.msg import String
from std_srvs.srv import SetBool


class ToyRover(Node):
    def __init__(self):
        super().__init__('toy_rover')
        self.heard = 0
        self.create_subscription(String, '/toy/status', self.on_status, 10)
        latched = QoSProfile(depth=10, durability=DurabilityPolicy.TRANSIENT_LOCAL,
                             reliability=ReliabilityPolicy.RELIABLE)
        self.create_subscription(String, '/toy/hints', self.on_hint, latched)
        self.pub_cmd = self.create_publisher(Twist, '/toy/cmd_vel', 10)
        self.cli_report = self.create_client(SetBool, '/toy/report')

    def on_hint(self, msg):
        self.get_logger().info(f'clue received: "{msg.data}"')

    def on_status(self, msg):
        self.heard += 1
        self.get_logger().info(f'status #{self.heard}: {msg.data}')
        cmd = Twist()
        cmd.linear.x = 0.5 if self.heard < 4 else 0.0        # drive for a while, then stop
        self.pub_cmd.publish(cmd)
        if self.heard in (2, 5) and self.cli_report.service_is_ready():
            stopped = self.heard == 5
            future = self.cli_report.call_async(SetBool.Request(data=stopped))
            future.add_done_callback(self.on_answer)          # do not block: the answer comes later
        if self.heard >= 6:
            raise SystemExit                                  # leave rclpy.spin()

    def on_answer(self, future):
        res = future.result()
        self.get_logger().info(f'referee says: success={res.success} message="{res.message}"')


def main():
    rclpy.init()
    node = ToyRover()
    try:
        rclpy.spin(node)
    except (SystemExit, KeyboardInterrupt, rclpy.executors.ExternalShutdownException):
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
