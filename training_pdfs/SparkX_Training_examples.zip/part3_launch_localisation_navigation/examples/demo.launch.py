"""demo.launch.py - the smallest launch file that uses every idea of SparkX's launch files.

    ros2 launch demo.launch.py                      # defaults
    ros2 launch demo.launch.py text:="rover ready"  # change a launch argument
    ros2 launch demo.launch.py listener:=false      # condition: skip the listener
    ros2 launch demo.launch.py --show-args          # list the arguments

Starts two nodes:
  beeper    our own script next to this file; parameter `text` comes from a launch argument
  listener  demo_nodes_py/listener; it listens on `chatter`, which we remap to `beep`,
            and it starts 2 s after the beeper (TimerAction), like the SparkX servers that wait
            for the simulator.
"""
import os

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, TimerAction
from launch.conditions import IfCondition
from launch.substitutions import LaunchConfiguration as L
from launch_ros.actions import Node

HERE = os.path.dirname(os.path.abspath(__file__))


def generate_launch_description():
    return LaunchDescription([
        # 1. launch arguments: settings you can give on the command line (name:=value)
        DeclareLaunchArgument('text', default_value='hello from SparkX'),
        DeclareLaunchArgument('listener', default_value='true'),

        # 2. a node with a parameter taken from a launch argument
        Node(executable=os.path.join(HERE, 'beeper.py'), name='beeper', output='screen',
             parameters=[{'text': L('text'), 'period_s': 0.5}]),

        # 3. a node from an installed package, remapped, started later, and only if asked for
        TimerAction(period=2.0, actions=[
            Node(package='demo_nodes_py', executable='listener', name='listener', output='screen',
                 remappings=[('chatter', 'beep')],
                 condition=IfCondition(L('listener'))),
        ]),
    ])
