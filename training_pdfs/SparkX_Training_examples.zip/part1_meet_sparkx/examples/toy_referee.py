#!/usr/bin/env python3
"""SparkX training, Part 1: a toy "referee" node (it is NOT the SparkX referee).

It shows the four things a ROS 2 node can offer, with the same shapes as the real referee:
  topic      /toy/status   std_msgs/String, once a second       (like /sparkx/mission/status)
  topic      /toy/hints    std_msgs/String, transient-local      (like /sparkx/mission/hints)
  service    /toy/report   std_srvs/SetBool                      (like /sparkx/mission/report_survivor)
  parameter  time_limit_s  float, default 900.0                  (like the referee's time_limit_s)

Run (in its own terminal):
  source /opt/ros/jazzy/setup.bash
  export ROS_DOMAIN_ID=41
  python3 toy_referee.py
"""
import rclpy
from rclpy.node import Node
from rclpy.qos import DurabilityPolicy, QoSProfile, ReliabilityPolicy
from std_msgs.msg import String
from std_srvs.srv import SetBool


class ToyReferee(Node):
    def __init__(self):
        super().__init__('toy_referee')                       # the node's name in the ROS graph
        self.time_limit = self.declare_parameter('time_limit_s', 900.0).value
        self.elapsed = 0
        self.score = 0

        # a plain topic: whoever listens now gets the next messages
        self.pub_status = self.create_publisher(String, '/toy/status', 10)

        # a "latched" topic: the last message is kept for subscribers that join later
        latched = QoSProfile(depth=10, durability=DurabilityPolicy.TRANSIENT_LOCAL,
                             reliability=ReliabilityPolicy.RELIABLE)
        self.pub_hint = self.create_publisher(String, '/toy/hints', latched)
        self.pub_hint.publish(String(data='Someone is about 15 m west of marker 12.'))

        # a service: one request in, one response out
        self.create_service(SetBool, '/toy/report', self.on_report)

        self.create_timer(1.0, self.tick)                     # call tick() once a second
        self.get_logger().info(f'toy referee ready, time limit {self.time_limit:.0f} s')

    def tick(self):
        self.elapsed += 1
        self.pub_status.publish(String(data=f'RUNNING t={self.elapsed}s/{self.time_limit:.0f}s score={self.score}'))

    def on_report(self, request, response):
        # request.data means "the rover is standing still" in this toy
        if request.data:
            self.score += 100
            response.success, response.message = True, 'CONFIRMED (+100)'
        else:
            self.score -= 25
            response.success, response.message = False, 'NOT_STOPPED (-25)'
        self.get_logger().info(f'report answered: {response.message}')
        return response


def main():
    rclpy.init()
    node = ToyReferee()
    try:
        rclpy.spin(node)                                      # wait for timers, requests, messages
    except (KeyboardInterrupt, rclpy.executors.ExternalShutdownException):
        pass
    finally:
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
