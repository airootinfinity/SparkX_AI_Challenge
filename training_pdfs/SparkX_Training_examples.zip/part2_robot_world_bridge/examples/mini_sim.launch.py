"""mini_sim.launch.py - the mini rover in simple_world (SparkX Training Part 2, Session 7).

The same four steps as src/sparkx_sim/launch/sim.launch.py, without the SparkX extras:
  1. start the Gazebo server on a world file
  2. publish the robot description (robot_state_publisher, simulated time)
  3. spawn the robot from /robot_description (ros_gz_sim create)
  4. bridge Gazebo topics to ROS 2 (ros_gz_bridge parameter_bridge)

Run it on your own practice PC, from this examples/ folder, with nothing else simulating:
  ros2 launch ./mini_sim.launch.py
Inspect it without starting anything:
  ros2 launch ./mini_sim.launch.py --print
"""
import os

from launch import LaunchDescription
from launch.actions import ExecuteProcess, TimerAction
from launch.substitutions import Command
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue

HERE = os.path.dirname(os.path.abspath(__file__))


def generate_launch_description():
    world = os.path.join(HERE, 'simple_world.sdf')
    xacro_file = os.path.join(HERE, 'mini_rover.urdf.xacro')
    bridge_yaml = os.path.join(HERE, 'mini_bridge.yaml')
    description = ParameterValue(Command(['xacro ', xacro_file]), value_type=str)
    return LaunchDescription([
        # 1. Gazebo server, headless (-s), running (-r); add the GUI with: gz sim -g
        ExecuteProcess(cmd=['gz', 'sim', '-s', '-r', world], output='screen'),
        # 2. URDF -> /robot_description and the fixed frames on /tf_static
        Node(package='robot_state_publisher', executable='robot_state_publisher',
             parameters=[{'robot_description': description, 'use_sim_time': True}]),
        # 3. spawn once the server is up
        TimerAction(period=3.0, actions=[Node(
            package='ros_gz_sim', executable='create', output='screen',
            arguments=['-world', 'simple_world', '-topic', 'robot_description', '-name', 'mini_rover',
                       '-x', '0', '-y', '0', '-z', '0.05'])]),
        # 4. the bridge, from a YAML list like SparkX's bridge_team.yaml
        Node(package='ros_gz_bridge', executable='parameter_bridge', name='mini_bridge',
             parameters=[{'config_file': bridge_yaml, 'use_sim_time': True}]),
    ])
