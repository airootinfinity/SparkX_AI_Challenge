#!/usr/bin/env python3
"""beeper.py - a tiny ROS 2 node for the launch-file exercise (SparkX training, part 3).

Publishes std_msgs/String on the topic `beep` every `period_s` seconds. The text comes from the
parameter `text`, so a launch file can change it without touching this code.

    python3 beeper.py --ros-args -p text:="hi" -p period_s:=1.0
"""
import rclpy
from rclpy.node import Node
from std_msgs.msg import String


class Beeper(Node):
    def __init__(self):
        super().__init__('beeper')
        self.text = self.declare_parameter('text', 'beep').value
        period = self.declare_parameter('period_s', 1.0).value
        self.pub = self.create_publisher(String, 'beep', 10)
        self.n = 0
        self.create_timer(period, self.tick)
        self.get_logger().info(f'beeper ready: text="{self.text}", every {period} s')

    def tick(self):
        self.n += 1
        self.pub.publish(String(data=f'{self.text} #{self.n}'))
        self.get_logger().info(f'sent #{self.n}')


def main():
    rclpy.init()
    node = Beeper()
    try:
        rclpy.spin(node)
    except (KeyboardInterrupt, rclpy.executors.ExternalShutdownException):
        pass
    finally:
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
