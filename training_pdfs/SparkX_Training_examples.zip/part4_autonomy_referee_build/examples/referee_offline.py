#!/usr/bin/env python3
"""Drive the SparkX referee core by hand, without Gazebo and without any running ROS node.

sparkx_referee/core.py is plain Python: it reads a world's answer sheet (private/scenario.yaml and
occluders.npz) and judges poses and reports. This script feeds it a few made-up rover poses on the
practice world practice_small_day and files rescue reports, so you can watch each check of
ReportSurvivor say yes or no. (Practice worlds ship their answers; competition worlds never do.)

  cd sparkx_ws && source install/setup.bash        # after colcon build (Session 13)
  python3 <path to>/referee_offline.py
"""
import math
import os

from ament_index_python.packages import get_package_share_directory
from sparkx_referee.core import Referee

world = os.path.join(get_package_share_directory('sparkx_worlds'), 'worlds', 'practice_small_day')
ref = Referee(world, team='demo')
s = ref.survivors['S04']                       # a person sitting in an open yard
ax, ay = s['x'] + 1.85, s['y']                 # a spot 1.85 m east of them
q = (0.0, 0.0, 1.0, 0.0)                       # facing west (yaw = pi)
t, here = 0.0, (ax, ay)


def tick(x, y, v, seconds):
    """Pretend the simulator ran: ground-truth pose (x, y) and speed v for `seconds`."""
    global t, here
    here = (x, y)
    for _ in range(int(seconds * 10)):
        t += 0.1
        for e in ref.update(t, (x, y, 0.05, *q), (v, 0.0)):
            print(f'  event {e["type"]:15s} {e["score_delta"]:+4d}  {e["description"]}')


def report(label, ex, ey):
    mx, my = ref.world_to_map(*here)           # a perfect map -> base_link, as if SLAM had no drift
    code, msg, sid, pts, err, hints, ev = ref.report('map', ex, ey, team_pose=(mx, my, math.pi))
    print(f'{label:34s} -> {code:20s} {pts:+4d}  {msg}')


ref.update(t, (ax, ay, 0.05, *q), (0.0, 0.0))
ref.start_mission()
sx, sy = ref.world_to_map(s['x'], s['y'])      # where the person is, in map coordinates
tick(ax, ay, 0.4, 0.5)                         # arrive, still rolling
report('1. report while still moving', sx, sy)
tick(ax, ay, 0.0, 3.5)                         # stand still (and wait out the 3 s rate limit)
report('2. stopped, estimate 1.5 m off', sx, sy + 1.5)
tick(ax, ay, 0.0, 3.5)
report('3. stopped, estimate 0.3 m off', sx + 0.3, sy)
print(f'score now {ref.score}, rescued {ref.rescue_order}, clues released {ref.released}')
print('4. stay parked here for 62 s:')
tick(ax, ay, 0.0, 62.0)                        # the idle limit: 60 s without moving 0.5 m
s3 = ref.survivors['S03']                      # a person lying in rubble
bx, by = s3['x'], s3['y'] - 1.8                # 1.8 m south of them: rubble in between
tick(bx, by, 0.0, 3.0)
report('5. 1.8 m south of S03, view blocked', *ref.world_to_map(s3['x'], s3['y']))
print('6. park 1.8 m north of S03 for 11 s without reporting:')
tick(s3['x'], s3['y'] + 1.8, 0.0, 11.0)        # the report window: 10 s
print(f'final score {ref.score}; score items:')
for el, pts, typ, text, _ in ref.score_items:
    print(f'  t={el:5.1f} s  {pts:+7.1f}  {typ}')
