"""view_mini_rover.launch.py - look at the mini rover in RViz, no simulator (Part 2, Session 5).

  ros2 launch ./view_mini_rover.launch.py
In RViz: Fixed Frame = base_footprint, then Add -> RobotModel (Description Topic /robot_description)
and Add -> TF. Move the wheel sliders in the joint_state_publisher_gui window.
"""
import os

from launch import LaunchDescription
from launch.substitutions import Command
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue

HERE = os.path.dirname(os.path.abspath(__file__))


def generate_launch_description():
    description = ParameterValue(Command(['xacro ', os.path.join(HERE, 'mini_rover.urdf.xacro')]), value_type=str)
    return LaunchDescription([
        Node(package='robot_state_publisher', executable='robot_state_publisher',
             parameters=[{'robot_description': description}]),
        Node(package='joint_state_publisher_gui', executable='joint_state_publisher_gui'),
        Node(package='rviz2', executable='rviz2'),
    ])
