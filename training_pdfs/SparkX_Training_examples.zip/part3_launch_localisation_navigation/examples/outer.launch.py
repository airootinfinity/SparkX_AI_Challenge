"""outer.launch.py - include one launch file in another, and start it after an event.

    ros2 launch outer.launch.py

practice.launch.py includes sim.launch.py, referee.launch.py and baseline.launch.py the same way.
Here a one-shot process ("warm_up", it just sleeps 1.5 s) runs first; when it exits, an event
handler includes demo.launch.py with its own value for the launch argument `text`. (SparkX uses
TimerAction for its ordering; an event handler is the other tool you will meet.)
"""
import os

from launch import LaunchDescription
from launch.actions import ExecuteProcess, IncludeLaunchDescription, LogInfo, RegisterEventHandler
from launch.event_handlers import OnProcessExit
from launch.launch_description_sources import PythonLaunchDescriptionSource

HERE = os.path.dirname(os.path.abspath(__file__))


def generate_launch_description():
    warm_up = ExecuteProcess(cmd=['sleep', '1.5'], name='warm_up', output='screen')
    demo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(os.path.join(HERE, 'demo.launch.py')),
        launch_arguments={'text': 'included by outer'}.items())
    return LaunchDescription([
        warm_up,
        RegisterEventHandler(OnProcessExit(target_action=warm_up, on_exit=[
            LogInfo(msg='warm_up finished: starting demo.launch.py'),
            demo,
        ])),
    ])
